/* 1.Tạo các #include cần thiết */
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>

/* dành riêng cho AF_INET */
#include <netinet/in.h>
#include <arpa/inet.h>
//---------------------
#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <cstring>
#include <sstream>

using namespace std;

bool check_bracket(char inp[]) {

    stack<char> s;
    int i = 0;
    while (inp[i] != '\0') {

        if (inp[i] == '(') {
            s.push(inp[i]);
        }

        if (inp[i] == ')') {
            if (s.empty()) {
                return 0;
            }
            s.pop();
        }

        i++;
    }

    if (!s.empty()) {
        return 0;
    }
    return 1;

}

bool check_operator(char inp[]) {

    int i = 0;
    if (inp[i] == '*' || inp[i] == '/') {
        return 0;
    }

    stack<char> s;
    
    while (inp[i] != '\0') {
        
        if (inp[i] != '(' && inp[i] != ')' && inp[i] != '+' && inp[i] != '-' && inp[i] != '*' && inp[i] != '/' && inp[i] != ' ') {
            s.push(inp[i]);
            i++;
        }
        else if (inp[i] == '+' || inp[i] == '-' || inp[i] == '*' || inp[i] == '/') {
            if (s.top() == '+' || s.top() == '-' || s.top() == '*' || s.top() == '/'){
                return 0;
            }
            s.push(inp[i]);
            i++;
        }
        else {
            i++;
        }
        

    }

    return 1;

}

int postfix(char inp[]) {

    stack<char> s;
    queue<char> q;

    int i = 0;
     
    while (inp[i] != '\0') {

        if (inp[i] != '(' && inp[i] != ')' && inp[i] != '+' && inp[i] != '-' && inp[i] != '*' && inp[i] != '/' && inp[i] != ' ') {
            q.push(inp[i]);
        }

        if (inp[i] == '+' || inp[i] == '-' || inp[i] == '*' || inp[i] == '/') {

            if (s.empty()) {
                q.push(' ');
                s.push(inp[i]);
            }
            else if (s.top() == '(') {
                q.push(' ');
                s.push(inp[i]);
            }
            else if (s.top() == '+' || s.top() == '-') {

                if (inp[i] == '*' || inp[i] == '/') {
                    q.push(' ');
                    s.push(inp[i]);
                }

                if (inp[i] == '+' || inp[i] == '-') {
                  
                    while (!s.empty()) {
                        if (s.top() == '(') {
                            break;
                        }
                 
                        q.push(' ');
                        q.push(s.top());
                        q.push(' ');
                        s.pop();
                    }
                    s.push(' ');
                    s.push(inp[i]);
                }

            }
            else if (s.top() == '*' || s.top() == '/') {

                while (!s.empty()) {
                    if (s.top() == '(') {
                        break;
                    }
                    q.push(' ');
                    q.push(s.top());
                    q.push(' ');
                    s.pop();
                }
                s.push(inp[i]);
                   
        
            }

        }

        if (inp[i] == '(') {
            s.push(inp[i]);
        }

        if (inp[i] == ')') {

            char ch = s.top();
            s.pop();
            while (ch != '(') {
                q.push(' ');
                q.push(ch);
                ch = s.top();
                s.pop();
            }
            
        }

        i++;
    }

    while (!s.empty()) {
        q.push(' ');
        q.push(s.top());
        s.pop();
    }

    string k;

    while (!q.empty()) {
        k += q.front();
        q.pop();
    }

    stack<int> s1;
    
    for (int i = 0; i < k.size(); i++) {
        

        if (k[i] == ' ') continue;

        else if (isdigit(k[i]))
        {
            int num = 0;

            //extract full number
            while (isdigit(k[i]))
            {
                num = num * 10 + (int)(k[i] - '0');
                i++;
            }
            i--;

            s1.push(num);
            
        }
        else
        {
            int val1 = s1.top(); s1.pop();

            int val2 = s1.top(); s1.pop();

            switch (k[i])
            {
            case '+': s1.push(val2 + val1); break;
            case '-': s1.push(val2 - val1); break;
            case '*': s1.push(val2 * val1); break;
            case '/': s1.push(val2 / val1); break;

            }
        }

    }
    
    return s1.top();

}

int main()
{	
	
	int server_sockfd;
	cout << "Enter the number of clients allow access to server: ";
	int n; cin >> n;;
	int client_sockfd[n];

	int server_len, client_len;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;
	
	/* 2. Thực hiện khởi tạo socket mới cho trình chủ */
	server_sockfd = socket( AF_INET, SOCK_STREAM, 0 );
	
	/* 3. Đặt tên và gán địa chỉ kết nối cho socket theo giao thức Internet */
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = inet_addr( "127.0.0.1" );
	server_address.sin_port = htons( 9734 );
	server_len = sizeof( server_address );
	
	/* 4. Ràng buộc tên với socket */
	bind( server_sockfd, (struct sockaddr *)&server_address, server_len );
	
	/* 5. Mở hàng đợi nhận kết nối - cho phép đặt hàng vào hàng đợi tối đa 5 kết nối */
	listen( server_sockfd, 5 );
	
	/* 6. Lặp vĩnh viễn để chờ và xử lý kết nối của trình khách */
	int i = 0;
	while ( 1 ) {
				
		printf( "server waiting...\n" );
		/* Chờ và chấp nhận kết nối */
		client_sockfd[i++] = accept( server_sockfd, (struct sockaddr*)&client_address, (socklen_t*)&client_len );
		/* Đọc dữ liệu do trình khách gửi đến */
		if(i == n){
			break;
		}
	}	

// xu li chuoi
	i = 0;
	while(i <= n){

		char ch[2000];
		read( client_sockfd[i], ch, 2000 );
		int result = 0;
		stringstream ss;
		char out[2000];
		if (check_bracket(ch) == 1 && check_operator(ch) == 1) {
        	result = postfix(ch);
			ss << result;
			
			string k = ss.str();
			int i = 0;
			while(k[i] != '\0'){
				out[i] = k[i];
				i++;
			}
				out[i] = '\0';
    	}
    	else {
        	string k =  "Invalid mathematical expression";
			int i = 0;
			while(k[i] != '\0'){
				out[i] = k[i];
				i++;
			}
			out[i] = '\0';
   		}
		/* Gửi trả dữ liệu về cho trình khách */
		write( client_sockfd[i], &out,sizeof(out));
		/* Đóng kết nối */
		close( client_sockfd[i] );
		i++;
	}

//-------------------------------------------------------------------------


	
}